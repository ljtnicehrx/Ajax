<?php
header("content:text/xml;charset=utf-8");
echo  file_get_contents(filename:"ajax1.xml");
